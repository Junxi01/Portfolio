A1: Responsive Portfolio in HTML and CSS — Readme
=================================================

Name: Junxi Chen
Email: chen161402@gmail.com

1. How many assignment points do you believe you completed (replace the *'s with your numbers)?

10/10
- 1/1 Readme
- 2/2 Basic HTML content
- 1/1 Basic CSS styling
- 1/1 Advanced feature
- 2/2 Responsive layout
- 1/1 Passes validation checks
- 2/2 Embraces spirit of the assignment

2. What (a) basic features, (b) CSS features, and (c) advanced features did you include in your portfolio?

(a) Basic features
- Images with descriptive alt attributes (e.g., profile and project thumbnails)
- Appropriate headings and paragraph text (single <h1> per page; logical heading order)
- Links to external pages (GitHub, LinkedIn, etc., opened with rel="noopener")
- Multiple pages with clear navigation between them (Home, Projects, About, Contact, Validations)
- Semantic HTML tags (header, nav, main, section, article, footer)
- Custom icons from Google Material Icons

(b) CSS features
- Readability-focused spacing (margins/padding) and typographic scale
- Custom color scheme and link states
- Google Fonts (“Inter”) with system-font fallbacks
- Responsive helpers via Grid/Flex utility classes
- (Bootstrap helpers not used)

(c) Advanced features
- Complex, responsive page layout (Grid/Flex) with sticky header and CSS-only hamburger menu for mobile
- Accessible data table with <caption> and proper <th scope="col|row">
- Contact form with labeled fields, required/aria-required, helper text, and a spam “honeypot” field
- (Optional/Not included) HTML5 media with fallbacks

3. Did you ignore any of the warnings or errors presented by the accessibility checker? If so, why does this not seem like an accessibility concern? If it's useful, you can consolidate your thoughts on multiple warnings/errors if the rationale is similar.

- Hamburger menu toggle: The mobile navigation uses a CSS-only checkbox pattern. Some tools suggest dynamically reflecting the state via aria-expanded on the toggle. Without JavaScript, this attribute cannot be updated in real time; keyboard/focus order remains correct, and the menu is operable via keyboard and screen readers. Given the assignment’s scope and the absence of scripting, this is an acceptable trade-off.
- Muted text contrast: The “.muted” class is applied only to secondary, non-essential meta text on high-contrast backgrounds. Primary content and interactive elements meet or exceed contrast guidelines. Retaining a slightly lighter tone improves visual hierarchy while preserving overall accessibility.

4. How long, in hours, did it take you to complete this assignment?

~6-7 hours

5. What online resources did you consult when completing this assignment? (list specific URLs, describe queries to Generative AI, or use of AI-based code completion)

- MDN Web Docs (Accessibility): https://developer.mozilla.org/en-US/docs/Learn/Accessibility
- WAI-ARIA Authoring Practices: https://www.w3.org/WAI/ARIA/apg/
- MDN (CSS Grid): https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_Grid_Layout
- MDN (Flexbox): https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_flexible_box_layout
- Google Fonts (Inter): https://fonts.google.com/specimen/Inter
- Google Material Icons: https://fonts.google.com/icons
- W3C HTML Validator: https://validator.w3.org/
- W3C CSS Validator: https://jigsaw.w3.org/css-validator/
- WAVE Web Accessibility Evaluation Tool: https://wave.webaim.org/
- Chrome DevTools Device Emulation: https://developer.chrome.com/docs/devtools/device-mode/

(Generative AI usage) I used ChatGPT for minor copyediting/microcopy ideas，code check and improvement advise offer, and to sanity-check alt-text phrasing. All code structure, visual design decisions, and final implementation are my own.

6. What classmates or other individuals did you consult as part of this assignment? What did you discuss?

None.

7. Is there anything special we need to know in order to run your code

- No build steps or dependencies. Open index.html in a modern browser.
- All assets use relative paths and should render on graders’ machines.
- Validation screenshots are included in /validation as:
  - valid-html-index.jpg, valid-html-about.jpg, valid-html-projects.jpg, valid-html-contact.jpg
  - valid-css-global.jpg
  - valid-accessibility-index.jpg
- The contact form’s action is a placeholder; no network submission occurs without replacing it with a real endpoint.